package com.lms.util;

import org.springframework.beans.BeanUtils;

import org.springframework.stereotype.Component;

import com.lms.dto.AdminDTO;
import com.lms.dto.AuthorDTO;
import com.lms.dto.BookDTO;
import com.lms.dto.GenreDTO;
import com.lms.dto.UserDTO;
import com.lms.entities.Admin;
import com.lms.entities.Author;
import com.lms.entities.Book;
import com.lms.entities.Genre;
import com.lms.entities.User;

@Component
public class Converter {

	public User convertToUserEntity(UserDTO userDTO) {
		User user = new User();
		if (user!= null) {
			BeanUtils.copyProperties(userDTO, user);
		}
		return user;
	}

	// convert from dto to entity
	public Book convertToBookEntity(BookDTO bookDTO) {
		Book book = new Book();
		if (book != null) {
			BeanUtils.copyProperties(bookDTO, book);
		}
		return book;
	}

	public Admin convertToAdminEntity(AdminDTO adminDTO) {
		Admin admin = new Admin();
		if (admin != null) {
			BeanUtils.copyProperties(adminDTO, admin);
		}
		return admin;
	}

	// convert from Entity to DTO
	public UserDTO convertToUserDTO(User user) {
		UserDTO userDTO = new UserDTO();
		if (userDTO != null) {
			BeanUtils.copyProperties(user, userDTO);
		}
		return userDTO;
	}

	public BookDTO convertToBookDTO(Book book) {

		BookDTO bookDTO = new BookDTO();

		if (bookDTO != null) {
			BeanUtils.copyProperties(book, bookDTO);
		}
		return bookDTO;
	}

	public GenreDTO convertToGenreDTO(Genre genre) {

		GenreDTO genreDTO = new GenreDTO();

		if (genreDTO != null) {
			BeanUtils.copyProperties(genre, genreDTO);
		}
		return genreDTO;
	}

	public AuthorDTO convertToAuthorDTO(Author author) {

		AuthorDTO authorDTO = new AuthorDTO();

		if (authorDTO != null) {
			BeanUtils.copyProperties(author, authorDTO);
		}
		return authorDTO;
	}

	public AdminDTO convertToAdminDTO(Admin admin) {

		AdminDTO adminDTO = new AdminDTO();

		if (adminDTO != null) {
			BeanUtils.copyProperties(admin, adminDTO);
		}
		return adminDTO;
	}

}
