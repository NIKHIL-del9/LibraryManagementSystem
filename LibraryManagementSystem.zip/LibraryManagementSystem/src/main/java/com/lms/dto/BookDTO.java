package com.lms.dto;

import com.lms.entities.User;

import lombok.Data;


@Data
public class BookDTO {

	private Long id;
	private String title;
	private String author;
	private Long quantity;
	private boolean borrowed;
    private User borrowedBy;
    private Long admin_id;
    private Long genre_id;
    private Long author_id;
	
}
