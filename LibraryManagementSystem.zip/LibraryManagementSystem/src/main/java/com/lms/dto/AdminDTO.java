package com.lms.dto;

import lombok.Data;

@Data
public class AdminDTO {
	private Long id;
	private String name;
	private String email;
	private Long phone_no;
}
