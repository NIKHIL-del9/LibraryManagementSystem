package com.lms.dto;

import lombok.Data;

@Data
public class AuthorDTO {

	private Long id;
	private String name;
}
