package com.lms.service_implementation;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dto.GenreDTO;
import com.lms.entities.Genre;
import com.lms.repository.GenreRepository;
import com.lms.service.GenreService;
import com.lms.util.Converter;

@Service
public class GenreServiceImplement implements GenreService{
	@Autowired
	private GenreRepository genreRepository;
	@Autowired
	private Converter converter;

	public List<GenreDTO> findAll() {
		List<Genre> genre = genreRepository.findAll();
		List<GenreDTO> DTO_list = new ArrayList<>();
		for (Genre b : genre) {
			DTO_list.add(converter.convertToGenreDTO(b));
		}

		return DTO_list;
	}

	public GenreDTO save(Genre genre) {
		genre = genreRepository.save(genre);
		return converter.convertToGenreDTO(genre);
	}
	
	public void deleteById(Long id) {
		genreRepository.deleteById(id);
		
	}

	@Override
	public GenreDTO findById(Long id) {
		Genre genre = genreRepository.findById(id).get();
		return converter.convertToGenreDTO(genre);
	}
}
