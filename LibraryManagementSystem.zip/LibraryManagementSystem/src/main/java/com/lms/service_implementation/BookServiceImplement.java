package com.lms.service_implementation;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dto.BookDTO;
import com.lms.entities.Book;
import com.lms.entities.User;
import com.lms.repository.BookRepository;
import com.lms.repository.UserRepository;
import com.lms.service.BookService;
import com.lms.util.Converter;

@Service
public class BookServiceImplement implements BookService {
	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private Converter converter;

	public List<BookDTO> findAll() {
		List<Book> book = bookRepository.findAll();
		List<BookDTO> DTO_list = new ArrayList<>();
		for (Book b : book) {
			DTO_list.add(converter.convertToBookDTO(b));
		}

		return DTO_list;
	}

	public BookDTO findById(Long id) {
		Book book = bookRepository.findById(id).get();
		return converter.convertToBookDTO(book);
	}

	
	@Override
	public void deleteById(Long id) {
		bookRepository.deleteById(id);
	}

	

	public BookDTO borrowBook(Long bookId, Long userId) {
		Book book = bookRepository.findById(bookId).get();
		User user = userRepository.findById(userId).orElse(null);

		if (book != null && !book.isBorrowed() && user != null) {
			book.setBorrowedBy(user);
			book.setBorrowed(true);
			return save(book);
		}
		return converter.convertToBookDTO(book);
	}

	@Override
	public BookDTO save(Book book) {
		book = bookRepository.save(book);
		return converter.convertToBookDTO(book);
	}

	

	
	

}
