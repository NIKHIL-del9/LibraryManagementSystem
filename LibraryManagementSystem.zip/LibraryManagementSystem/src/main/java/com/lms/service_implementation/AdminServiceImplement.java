package com.lms.service_implementation;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dto.AdminDTO;
import com.lms.entities.Admin;
import com.lms.repository.AdminRepository;
import com.lms.service.AdminService;
import com.lms.util.Converter;

@Service
public class AdminServiceImplement implements AdminService {

	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	private Converter converter;

	@Override
	public List<AdminDTO> findAll() {
		List<Admin> admin = adminRepository.findAll();
		List<AdminDTO> adminDTO = new ArrayList<>();
		for (Admin a : admin) {
			adminDTO.add(converter.convertToAdminDTO(a));
		}
		return adminDTO;
	}

	@Override
	public AdminDTO save(Admin admin) {
		admin = adminRepository.save(admin);
		return converter.convertToAdminDTO(admin);
	}

	@Override
	public void delete(Long id) {
		adminRepository.deleteById(id);

	}

	@Override
	public AdminDTO findById(Long id) {
		Admin admin = adminRepository.findById(id).get();
		return converter.convertToAdminDTO(admin);
	}

	@Override
	public AdminDTO update(Long id, Admin admin) {
		Admin a = adminRepository.findById(id).get();
		a.setId(admin.getId());
		a.setName(admin.getName());
		a.setEmail(admin.getEmail());
		a.setPhone_no(admin.getPhone_no());
		Admin ad = adminRepository.save(a);
		return converter.convertToAdminDTO(ad);
	}

}
