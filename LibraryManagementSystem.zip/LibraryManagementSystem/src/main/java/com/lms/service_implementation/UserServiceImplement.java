package com.lms.service_implementation;

import java.util.ArrayList;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dto.BookDTO;
import com.lms.dto.UserDTO;
import com.lms.entities.User;
import com.lms.repository.BookRepository;
import com.lms.repository.UserRepository;
import com.lms.service.UserService;
import com.lms.util.Converter;

@Service
public class UserServiceImplement implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private Converter converter;

	public List<BookDTO> findAll() {
		List<com.lms.entities.Book> book = bookRepository.findAll();
		List<BookDTO> DTO_list = new ArrayList<>();
		for (com.lms.entities.Book b : book) {
			DTO_list.add(converter.convertToBookDTO(b));
		}

		return DTO_list;
	}

	@Override
	public List<UserDTO> findAllUsers() {
		List<User> user = userRepository.findAll();
		List<UserDTO> DTO_list = new ArrayList<>();
		for (User u : user) {
			DTO_list.add(converter.convertToUserDTO(u));
		}
		return DTO_list;
	}

	@Override
	public UserDTO save(User user) {
		user = userRepository.save(user);

		return converter.convertToUserDTO(user);
	}

	@Override
	public void deleteById(Long id) {
		userRepository.deleteById(id);
	}

	@Override
	public UserDTO findById(Long id) {
		User user = userRepository.findById(id).get();
		return converter.convertToUserDTO(user);
	}

	@Override
	public UserDTO update(Long id, User user) {
		User u = userRepository.findById(id).get();
		u.setId(user.getId());
		u.setName(user.getName());
		u.setEmail(user.getEmail());
		u.setPhone_no(user.getPhone_no());

		User u1 = userRepository.save(u);

		return converter.convertToUserDTO(u1);
	}

}
