package com.lms.service_implementation;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lms.dto.AuthorDTO;
import com.lms.entities.Author;
import com.lms.repository.AuthorRepository;
import com.lms.service.AuthorService;
import com.lms.util.Converter;

@Service
public class AuthorServiceImplement implements AuthorService {

	@Autowired
	private AuthorRepository authorRepository;

	@Autowired
	private Converter converter;

	@Override
	public List<AuthorDTO> findAll() {

		List<Author> author = authorRepository.findAll();
		List<AuthorDTO> DTO_list = new ArrayList<>();
		for (Author a : author) {

			DTO_list.add(converter.convertToAuthorDTO(a));
		}
		return DTO_list;
	}

	@Override
	public AuthorDTO save(Author author) {
		author = authorRepository.save(author);
		return converter.convertToAuthorDTO(author);
	}

	@Override
	public void DeleteById(Long id) {
		authorRepository.deleteById(id);

	}

	@Override
	public AuthorDTO findById(Long id) {
		Author author = authorRepository.findById(id).get();
		return converter.convertToAuthorDTO(author);
	}

}
