package com.lms.service;

import java.util.List;

import com.lms.dto.AdminDTO;
import com.lms.entities.Admin;

public interface AdminService {

	List<AdminDTO> findAll();
	
	AdminDTO findById(Long id);
	
	AdminDTO save(Admin admin);
	
	void delete(Long id);
	
	AdminDTO update(Long id,Admin admin);
}
