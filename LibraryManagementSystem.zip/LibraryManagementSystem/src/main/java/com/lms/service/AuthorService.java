package com.lms.service;

import java.util.List;

import com.lms.dto.AuthorDTO;
import com.lms.entities.Author;


public interface AuthorService {

	List<AuthorDTO> findAll();
	
	AuthorDTO findById(Long id);

	AuthorDTO save(Author author);

	void DeleteById(Long id);
}
