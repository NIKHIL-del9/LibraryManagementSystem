package com.lms.service;

import java.util.List;

import com.lms.dto.BookDTO;
import com.lms.entities.Book;


public interface BookService {

	List<BookDTO> findAll();

	BookDTO findById(Long id);

	BookDTO save(Book book);

	void deleteById(Long id);

	BookDTO borrowBook(Long bookId, Long userId);
	
}
