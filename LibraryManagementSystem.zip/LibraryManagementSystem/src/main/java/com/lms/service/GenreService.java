package com.lms.service;

import java.util.List;

import com.lms.dto.GenreDTO;
import com.lms.entities.Genre;

public interface GenreService {

	List<GenreDTO> findAll();

	GenreDTO findById(Long id);
	
	GenreDTO save(Genre genre);

	void deleteById(Long id);
}
