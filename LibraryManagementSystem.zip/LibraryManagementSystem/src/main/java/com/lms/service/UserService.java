package com.lms.service;

import java.util.List;

import com.lms.dto.UserDTO;
import com.lms.entities.User;

public interface UserService {

	List<UserDTO> findAllUsers();

	UserDTO findById(Long id);

	UserDTO save(User user);

	void deleteById(Long id);

	UserDTO update(Long id, User user);
}
