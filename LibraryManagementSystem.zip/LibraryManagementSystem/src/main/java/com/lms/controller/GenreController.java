package com.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.dto.GenreDTO;
import com.lms.entities.Genre;
import com.lms.service.GenreService;

@RestController
@RequestMapping("/api/genre")
public class GenreController {

	@Autowired
	private GenreService genreService;

	@GetMapping
	public List<GenreDTO> getAllGenre() {
		return genreService.findAll();
	}
    
	@GetMapping("/{id}")
	public GenreDTO getGenreById(@PathVariable Long id) {
		return genreService.findById(id);
	}
	
	
	@PostMapping
	public GenreDTO addGenre(@RequestBody Genre genre) {
		return genreService.save(genre);
	}

	@DeleteMapping("/{id}")
	public void deleteGenre(@PathVariable Long id) {
		genreService.deleteById(id);
	}

}
