package com.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.dto.AdminDTO;
import com.lms.dto.AuthorDTO;
import com.lms.dto.BookDTO;
import com.lms.dto.GenreDTO;
import com.lms.dto.UserDTO;
import com.lms.entities.Admin;
import com.lms.entities.Author;
import com.lms.entities.Book;
import com.lms.entities.Genre;
import com.lms.entities.User;
import com.lms.service.AdminService;
import com.lms.service.AuthorService;
import com.lms.service.BookService;
import com.lms.service.GenreService;
import com.lms.service.UserService;
import com.lms.util.Converter;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

	@Autowired
	private AdminService adminService;

	@Autowired
	private BookService bookService;

	@Autowired
	private UserService userService;

	@Autowired
	private GenreService genreService;

	@Autowired
	private AuthorService authorService;
	
	@Autowired
	private Converter converter;
	

	@GetMapping("/users/showUsers")
	public List<UserDTO> getAllUsers() {
		return userService.findAllUsers();
	}

	@GetMapping("/users/showUser/{id}")
	public UserDTO getUserById(@PathVariable Long id) {
		return userService.findById(id);
	}
	
	@PutMapping("/users/updateUser/{id}")
	public UserDTO updateUser(@PathVariable Long id, @RequestBody UserDTO userDTO) {

		final User user = converter.convertToUserEntity(userDTO);
		return userService.update(id, user);

	}

	@PostMapping("/users/addUser")
	public UserDTO addUser(@RequestBody User user) {
		return userService.save(user);
	}

	@DeleteMapping("/users/{id}")
	public void removeUser(@PathVariable Long id) {
		userService.deleteById(id);

	}

	@GetMapping("/books/showBooks")
	public List<BookDTO> getAllBooks() {

		return bookService.findAll();
	}

	@GetMapping("/books/showBook/{id}")
	public BookDTO getBookById(@PathVariable Long id) {
		return bookService.findById(id);
	}

	@PostMapping("/books/addBook")
	public BookDTO addBook(@RequestBody Book book) {
		return bookService.save(book);
	}

	@DeleteMapping("/books/{id}")
	public void removeBook(@PathVariable Long id) {
		bookService.deleteById(id);
	}

	@GetMapping("/genre/showGenre")
	public List<GenreDTO> getAllGenre() {
		return genreService.findAll();
	}

	@GetMapping("/genre/showGenre/{id}")
	public GenreDTO getGenreById(@PathVariable Long id) {
		return genreService.findById(id);
	}

	@PostMapping("/genre/addGenre")
	public GenreDTO addGenre(@RequestBody Genre genre) {
		return genreService.save(genre);
	}

	@DeleteMapping("/genre/{id}")
	public void removeGenre(@PathVariable Long id) {
		genreService.deleteById(id);
	}

	@GetMapping("/author/showAuthors")
	public List<AuthorDTO> getAllAuthors() {
		return authorService.findAll();
	}

	@GetMapping("/author/showAuthor/{id}")
	public AuthorDTO getAuthorById(@PathVariable Long id) {
		return authorService.findById(id);
	}

	@PostMapping("/author/addAuthor")
	public AuthorDTO addAuthor(@RequestBody Author author) {
		return authorService.save(author);

	}

	@DeleteMapping("/author/{id}")
	public void removeAuthor(@PathVariable Long id) {
		authorService.DeleteById(id);
	}

	@GetMapping
	public List<AdminDTO> getAllAdmin() {
		return adminService.findAll();
	}

	@GetMapping("/{id}")
	public AdminDTO getAdminById(@PathVariable Long id) {

		return adminService.findById(id);
	}
	
	@PutMapping("/{id}")
	public AdminDTO updateAdmin(@Validated  @PathVariable Long id,@RequestBody AdminDTO adminDTO) {
		final Admin admin=converter.convertToAdminEntity(adminDTO);
		return adminService.update(id,admin);
		
	}

	@PostMapping("/addAdmin")
	public AdminDTO addAdmin(@RequestBody Admin admin) {
		return adminService.save(admin);
	}

	@DeleteMapping("/{id}")
	public void removeAdmin(Long id) {
		adminService.delete(id);
	}
}
