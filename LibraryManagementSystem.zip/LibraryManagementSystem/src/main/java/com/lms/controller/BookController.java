package com.lms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lms.dto.BookDTO;
import com.lms.entities.Book;
import com.lms.service.BookService;

@RestController
@RequestMapping("/api/Books")
public class BookController {
	@Autowired
	private BookService bookService;

	@GetMapping
	public List<BookDTO> getAllBook() {
		return bookService.findAll();
	}

	@GetMapping("/{id}")
	public BookDTO getBook(@PathVariable Long id) {
		return bookService.findById(id);
	}

	@PostMapping
	public BookDTO addBook(@RequestBody Book book) {
		return bookService.save(book);
	}

	@DeleteMapping("/{id}")
	public void deleteBook(@PathVariable Long id) {
		bookService.deleteById(id);
	}

	@PostMapping("/{bookId}/borrow/{userId}")
	public ResponseEntity<BookDTO> borrowBook(@PathVariable Long bookId, @PathVariable Long userId) {
		BookDTO borrowedBook = bookService.borrowBook(bookId, userId);
		if (borrowedBook != null) {
			return ResponseEntity.ok(borrowedBook);
		} else {
			return ResponseEntity.badRequest().build(); // or a more descriptive error response
		}
	}

}
