package com.lms.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.lms.entities.Genre;



public interface GenreRepository extends JpaRepository<Genre, Long> {
}